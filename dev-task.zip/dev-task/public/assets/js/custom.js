//when student picks a time
$(document).on('input', "#examdaytime", function () {
    $(".examdateValidation").html("");

});

//when student enters comment
$(document).on('input', ".studentComment", function () {
    $(".commentValidation").html("*");

});

// show modal when student clicks on register button
function sendrequest(courseid){
    var courseName = $('.courseName'+courseid).html();
    $('.modal-title').html('Exam Registeration for '+courseName);
    $(".selectedCourseId").val(courseid);


    $(".screen1").css("display","block");
    $(".screen3").show();
    $('#examdaytime'). val('0000-00-00');
    $('.studentComment').val('');
    $('.textToDisplay').html('');
    $(".nextBtn").show();

    $('#examReqModal').modal('show');
}

// function to show next screen after student press the next button in modal
function showScreen2(){
    //var courseid = $(".selectedCourseId").val(courseid);
    var examdaytime = $("#examdaytime").val();
    var examtime = new Date(examdaytime);
    var nowtime = new Date();
    if (examtime > nowtime) {
        var selectedTime = examdaytime.split("T");
        var textToDisplay = "Exam Date and Time: "+selectedTime[0]+" "+selectedTime[1];
        $(".textToDisplay").html(textToDisplay);
        $(".screen1").hide();
        $(".nextBtn").hide();
        $(".screen2").show();
        $(".backBtn").show();
        $(".submitBtn").show();
    }
    else{
        $(".examdateValidation").html("Please select a valid Date and Time");
    }
}

// function to show previous screen after student press the back button in modal
function showScreen1(){
    //var courseid = $(".selectedCourseId").val(courseid);
    var examdaytime = $("#examdaytime").val();
    
    $(".screen1").show();
    $(".nextBtn").show();
    $(".screen2").hide();
    $(".backBtn").hide();
    $(".submitBtn").hide();
}

// validation and ajax call after student press the submit button
function submitRequest(){
    var courseId = $(".selectedCourseId").val();
    var studentComments = $(".studentComment").val();
    var examdaytime = $("#examdaytime").val();
    var csrfName = $('.txt_csrfname').attr('name'); 
    var csrfHash = $('.txt_csrfname').val(); 
    
    if(studentComments == ""){
        $(".commentValidation").html("* Please enter Comment");
    }
    else{
        $(".backBtn").hide();
        $(".submitBtn").hide();
        $.ajax({
            url: 'requestForExam',
            type: 'POST',
            data: {courseId:courseId, studentComments: studentComments, examdaytime: examdaytime, [csrfName]: csrfHash},
            error: function() {
                $(".backBtn").show();
                $(".submitBtn").show();
            },
            success: function(data) {  
                var obj = jQuery.parseJSON(data);
                $('.txt_csrfname').val(obj.token);
                if(obj.result_status == '1'){
                    $('.txt_csrfname').val(obj.token);
                    $(".requestBox"+courseId).html('<span class="label label-warning">Request Pending (Applied on '+obj.requestTime+')</span>');
                    $(".applyBox"+courseId).html(obj.applyTime);
                    $(".screen3").html("<p class='textToDisplay'>Request Submitted. Waiting for Approval</p>");
                    $(".screen3").show();
                    $(".screen2").hide();
                    $(".closeBtn").show();
                }
                else{
                    $(".screen2").hide();
                    $(".screen3").html("<p class='textToDisplay'>Unable to process request. Please try after some time</p>");
                    $(".screen3").show();
                }
            }
         });
    }
}

//clear the selected fields after the modal is closed
$('#examReqModal').on('hidden.bs.modal', function () {   
    $(".screen1").css("display","block");
    $(".screen3").show();
    $('#examdaytime'). val('0000-00-00');
    $('.studentComment').val('');
    $('.textToDisplay').html();
  });

  