<?php

namespace App\Validation;

use App\Models\Professor\ProfessorModel;

class Professorrules
{
    // public function custom_rule(): bool
    // {
    //     return true;
    // }
    public function validateProfessor(string $str, string $fields, array $data){   
        $model = new ProfessorModel();
        $user = $model->where('professor_email', $data['professor_email'])
                      ->first();
                      
        
        if(!$user)
          return false;
    
          //echo password_hash("stu1123", PASSWORD_DEFAULT);die;
        return password_verify($data['professor_password'], $user['professor_password']); 
      }
}
