<?php

namespace App\Controllers;

use App\Controllers\BaseController;
use App\Models\CoursesModel;
use App\Models\CustomModel;
use App\Models\ExamRequestsModel;

class Courses extends BaseController
{
    private $db;

    public function __construct()
    {
        $this->db = db_connect(); // Loading database
        // OR $this->db = \Config\Database::connect();
    }

    public function getCourses()
    {
        
        $db = db_connect();
        $model = new CustomModel($db);
        $data['allCourses'] = $model->getCourses();       
        
        return view('courses', $data);
    }

    public function submitData()
    {
        $model = new ExamRequestsModel();
        //$data = $this->request->getVar(); // all form data into $data variable
        $requestTime = date("Y-m-d H:i:s");
        $insertData = [
            'course_id' => $this->request->getVar('courseId'),
            'student_id' => session()->get('id'),
            'exam_date' => $this->request->getVar('examdaytime'),
            'student_comment' => $this->request->getVar('studentComments',FILTER_SANITIZE_STRING),
            'request_time' => $requestTime,
            'approval_status' => 0,
            'approved_time' => NULL,
            'professor_id' => NULL
            
        ];
        
        $result = $model->insert($insertData);
        if($result){
            $data['result_status'] = 1;
        }
        $data['requestTime'] = date('d-m-Y h:i:s a', strtotime($requestTime));
        $data['applyTime'] = date('d-m-Y h:i:s a', strtotime($this->request->getVar('examdaytime')));
        $data['token'] = csrf_hash();
        return json_encode($data);
    }
}