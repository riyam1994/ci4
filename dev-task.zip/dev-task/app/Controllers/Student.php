<?php

namespace App\Controllers;

use App\Controllers\BaseController;
use App\Models\StudentModel;

class Student extends BaseController
{
    public function login()
    {
        $data = [];

        if ($this->request->getMethod() == 'post') {
            
            $rules = [
                'student_email' => 'required|min_length[6]|max_length[50]|valid_email',
                'student_password' => 'required|min_length[4]|max_length[255]|validateStudent[student_email,student_password]',
            ];

            $errors = [
                'password' => [
                    'validateStudent' => "Email or Password don't match",
                ],
            ];

            if (!$this->validate($rules, $errors)) {
                
                return view('login', [
                    "validation" => $errors,//"validation" => $this->validator,
                ]);

            } else {
                $model = new StudentModel();
                
                $student = $model->where('student_email', $this->request->getVar('student_email',FILTER_SANITIZE_EMAIL))
                    ->first();

                // Stroing session values
                $this->setStudentSession($student);
                // Redirecting to dashboard after login
                return redirect()->to(base_url('dashboard'));

            }
        }
        return view('login');
    }

    private function setStudentSession($student)
    {
        $data = [
            'id' => $student['id'],
            'student_name' => $student['student_name'],
            'isLoggedIn' => true,
        ];

        session()->set($data);
        return true;
    }

    public function profile()
    {

        $data = [];
        $model = new StudentModel();

        $data['student'] = $model->where('id', session()->get('id'))->first();
        return view('profile', $data);
    }

    public function logout()
    {
        //session()->destroy();
        session()->remove('id');
        session()->remove('student_name');
        session()->remove('isLoggedIn');
        return redirect()->to(base_url('login'));
    }
}