<?php

namespace App\Controllers\Professor;

use App\Controllers\BaseController;
use App\Models\Professor\EnrolmentModel;
use App\Models\Professor\CustomModel;
use App\Models\Professor\CoursesModel;

class Enrolments extends BaseController
{
    private $db;

    public function __construct()
    {
        $this->db = db_connect(); // Loading database
    }

    public function getEnrolmentDatailsById($courseId){
        $db = db_connect();
        $model = new CustomModel($db);
        $data['allEnrolments'] = $model->getEnrolments($courseId);  
        
        $model = new CoursesModel($db);
        $data['courseDetails'] = $model->where('id', $courseId)
        ->first(); 
        
        return view('Professor/enrolments', $data);
    }
    public function showRequests(){
		//$recordId = $this->request->getVar('recordId');
        $data = $this->request->getVar(); 
        $recordId = $this->request->getVar('recordId'); 
       
        $db = db_connect();
        $model = new CustomModel($db);

        $enrolmentDetail = $model->getenrolmentDetail($recordId);  
        

		$html = "";
		foreach($enrolmentDetail as $enrolment){
			$html .= '<input type="hidden" class="selectedrowId" value="'.$recordId.'" />
            <p>Exam Name: '.$enrolment->course_name.'</p>
            <p>Student Name: '.$enrolment->student_name.'</p>
			<p>Applied On: '.date('F jS, Y h:i:s a', strtotime($enrolment->request_time)).'</p>
			<p>Requested Date: '.date('F jS, Y h:i:s a', strtotime($enrolment->exam_date)).'</p>
            <p>Student Comment: '.$enrolment->student_comment.'</p>
           
            
            <hr>
				<span class="actionButton">
					<button type="button" class="btn btn-primary" onclick="submitApproval(1);">APPROVE</button>
					<button type="button" class="btn btn-danger" onclick="submitApproval(2);">DECLINE</button>
				</span>';
		}
		$data['modal_html'] = $html;
        $data['token'] = csrf_hash();
		return json_encode($data);

	}

	public function submitApproval()
	{
        
        $data = $this->request->getVar(); 

        $db = db_connect();
        $model = new EnrolmentModel($db);

        $recordId = $this->request->getVar('recordId');
        $professorId = session()->get('Pid');//$this->session->userdata['logged_pId'.base_url()];
		$approvalTime =  date("Y-m-d H:i:s");	

       $newData = [
            'approval_status'  => $this->request->getVar('approvalType'),
            'approved_time' => $approvalTime,
            'professor_id' => $professorId
        ];
        
         //$model->save($newData);
        if($model->update($recordId,$newData)){
            $data['result_status'] = 1;
        }
        $data['approvalTime'] = date('F jS, Y  h:i:s a', strtotime($approvalTime));


		
		$data['token'] = csrf_hash();
		return json_encode($data);

	}

    
}