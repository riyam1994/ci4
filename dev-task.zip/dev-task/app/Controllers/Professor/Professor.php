<?php

namespace App\Controllers\Professor;

use App\Controllers\BaseController;
use App\Models\Professor\ProfessorModel;

class Professor extends BaseController
{
    public function login()
    {
        $data = [];

        if ($this->request->getMethod() == 'post') {
            
            $rules = [
                'professor_email' => 'required|min_length[6]|max_length[50]|valid_email',
                'professor_password' => 'required|min_length[4]|max_length[255]|validateProfessor[professor_email,professor_password]',
            ];

            $errors = [
                'password' => [
                    'validateProfessor' => "Email or Password don't match",
                ],
            ];

            if (!$this->validate($rules, $errors)) {
                
                return view('Professor/login', [
                    "validation" => $errors,//"validation" => $this->validator,
                ]);

            } else {
                $model = new ProfessorModel();
                
                $professor = $model->where('professor_email', $this->request->getVar('professor_email',FILTER_SANITIZE_EMAIL))
                    ->first();

                // Stroing session values
                $this->setProfessorSession($professor);
                // Redirecting to dashboard after login
                return redirect()->to(base_url('professor-dashboard'));

            }
        }
        return view('Professor/login');
    }

    private function setProfessorSession($professor)
    {
        $data = [
            'Pid' => $professor['id'],
            'professor_name' => $professor['professor_name'],
            'isPLoggedIn' => true,
        ];

        session()->set($data);
        return true;
    }
    public function profile()
    {
        
        $data = [];
        $model = new ProfessorModel();

        $data['professor'] = $model->where('id', session()->get('Pid'))->first();
        return view('professor/profile', $data);
    }
    public function logout()
    {
        //session()->destroy();
        session()->remove('Pid');
        session()->remove('professor_name');
        session()->remove('isPLoggedIn');
        
        return redirect()->to(base_url('professor-login'));
    }
}
