<?php

namespace App\Controllers\Professor;

use App\Controllers\BaseController;
use App\Models\Professor\CoursesModel;

class Courses extends BaseController
{
    private $db;

    public function __construct()
    {
        $this->db = db_connect(); // Loading database
        // OR $this->db = \Config\Database::connect();
    }

    public function getCourses()
    {
        
        $model = new CoursesModel();
                
        $data['allCourses'] = $model->findAll();  
        
        return view('professor\courses', $data);
    }

    public function submitData()
    {
        $model = new ExamRequestsModel();
        //$data = $this->request->getVar(); // all form data into $data variable
        $requestTime = date("Y-m-d H:i:s");
        $insertData = [
            'course_id' => $this->request->getVar('courseId'),
            'student_id' => session()->get('id'),
            'exam_date' => $this->request->getVar('examdaytime'),
            'student_comment' => $this->request->getVar('studentComments'),
            'request_time' => $requestTime,
            'approval_status' => 0,
            'approved_time' => NULL,
            'professor_id' => NULL
            
        ];
        
        $result = $model->insert($insertData);
        if($result){
            $data['result_status'] = 1;
        }
        $data['requestTime'] = date('d-m-Y h:i:s a', strtotime($requestTime));
        $data['applyTime'] = date('d-m-Y h:i:s a', strtotime($this->request->getVar('examdaytime')));
        return json_encode($data);
    }
}