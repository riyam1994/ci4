<?php

namespace App\Controllers\Professor;

use App\Controllers\BaseController;

class Dashboard extends BaseController
{
    public function index()
    {
        return view("Professor/dashboard");
    }
}
