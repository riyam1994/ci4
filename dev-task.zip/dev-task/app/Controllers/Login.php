<?php

namespace App\Controllers;
use CodeIgniter\Controller;

class Login extends Controller{
    public function index(){
        
        echo view("login_view");
    }



    public function _remap($method,$param1 =null,$param2 = null){
        if(method_exists($this,$method)){
            return $this->$method($param1,$param2);
        }
        throw \CodeIgniter\Exceptions\PageNotFoundException::forPageNotFound();
    }
}