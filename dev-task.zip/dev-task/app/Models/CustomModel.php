<?php

namespace App\Models;

use CodeIgniter\Database\ConnectionInterface;

class CustomModel
{
    protected $db;

    public function __construct(ConnectionInterface &$db)
    {
        $this->db =& $db; 
    }


    function getCourses(){
        $student_id = session()->get('id');
        $builder = $this->db->table("tbl_courses as course");
        $builder->select('course.*,tbl_exam_requests.request_time,tbl_exam_requests.approval_status,tbl_exam_requests.exam_date,tbl_exam_requests.approved_time,tbl_professors.professor_name');
        $builder->join('tbl_exam_requests', "course.id = tbl_exam_requests.course_id and tbl_exam_requests.student_id = '$student_id'", "left"); // added left here
        $builder->join('tbl_professors', "tbl_professors.id=tbl_exam_requests.professor_id", "left"); // added left here
        $builder->where("course.status = '1'");
        $builder->orderBy("course.course_name asc");
        return  $builder->get()->getResult();
    }
}
