<?php

namespace App\Models\Professor;

use CodeIgniter\Database\ConnectionInterface;

class CustomModel
{
    protected $db;

    public function __construct(ConnectionInterface &$db)
    {
        $this->db =& $db; 
    }


    function getEnrolments($courseId){
       
        $builder = $this->db->table("tbl_exam_requests as examRequests");
        $builder->select('tbl_courses.course_name,examRequests.*,tbl_students.student_name,tbl_professors.professor_name,tbl_professors.id as profId');
        $builder->join('tbl_courses', "tbl_courses.id = examRequests.course_id", "left"); // added left join here
        $builder->join('tbl_students', "tbl_students.id = examRequests.student_id", "left"); // added left here
        $builder->join('tbl_professors', "examRequests.professor_id = tbl_professors.id", "left"); // added left here
        $builder->where("examRequests.course_id = '$courseId'");
        $builder->orderBy("examRequests.request_time asc");
        return  $builder->get()->getResult();

        //$data['allEnrolments'] = $this->common_function_model->join_five_tables('tbl_courses.course_name,tbl_exam_requests.*,tbl_students.student_name,tbl_professors.professor_name,tbl_professors.id as profId', 'tbl_courses', 'tbl_exam_requests', 'tbl_students', 'tbl_professors',NULL, "tbl_courses.id = tbl_exam_requests.course_id", "tbl_students.id = tbl_exam_requests.student_id", 'tbl_exam_requests.professor_id = tbl_professors.id', NULL,"tbl_exam_requests.course_id = '$courseId'", $joinType1 = 'left', $joinType2 = 'left', $joinType3 = 'left', $joinType4 = 'left', 'tbl_exam_requests.request_time asc',$groupBy = NULL);
    }

    function getenrolmentDetail($recordId){
        $builder = $this->db->table("tbl_exam_requests as examRequests");
        $builder->select('tbl_courses.course_name,examRequests.*,tbl_students.student_name');
        $builder->join('tbl_courses', "tbl_courses.id = examRequests.course_id", "left"); // added left join here
        $builder->join('tbl_students', "tbl_students.id = examRequests.student_id", "left"); // added left here
        $builder->where("examRequests.id = '$recordId'");
        return  $builder->get()->getResult();
    }
}
