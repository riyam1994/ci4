<?= $this->extend("Professor/layouts/app") ?>

<?= $this->section("pageTitle") ?>
Profile | Dev Task
<?= $this->endSection() ?>

<?= $this->section("body") ?>

<div class="container" style="margin-top:20px;">
    <div class="row">
        <div class="panel panel-primary">
            <div class="panel-heading">Profile</div>
            <div class="panel-body">
                <h3>Hi, <?= $professor['professor_name'] ?></h3>
                <hr>
                <p>Email: <?= $professor['professor_email'] ?></p>
            </div>
        </div>
    </div>
</div>

<?= $this->endSection() ?>