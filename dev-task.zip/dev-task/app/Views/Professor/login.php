<?= $this->extend("Professor/layouts/app") ?>

<?= $this->section("pageTitle") ?>
Login | Dev Task
<?= $this->endSection() ?>

<?= $this->section("body") ?>

<div class="container" style="margin-top:20px;">
    <div class="row">
        <div class="panel panel-primary">
            <div class="panel-heading">Professor Login</div>
            <div class="panel-body">
                <?php if (isset($validation)) : ?>
                    <div class="col-12">
                        <div class="alert alert-danger" role="alert">
                            <!-- $validation->listErrors()  -->
                            <?= $validation['password']['validateProfessor'] ?>
                        </div>
                    </div>
                <?php endif; ?>
                <form class="" action="<?= base_url('professor-login') ?>" method="post">
                <?= csrf_field() ?>
                    <div class="form-group">
                        <label for="email">Email</label>
                        <input type="email" class="form-control" name="professor_email" id="professor_email">
                    </div>
                    <div class="form-group">
                        <label for="password">Password</label>
                        <input type="password" class="form-control" name="professor_password" id="professor_password">
                    </div>
                    <button type="submit" class="btn btn-success">Submit</button>
                </form>
            </div>
        </div>
    </div>
</div>

<?= $this->endSection() ?>