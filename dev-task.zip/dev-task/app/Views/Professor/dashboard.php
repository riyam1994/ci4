<?= $this->extend("Professor/layouts/app") ?>

<?= $this->section("pageTitle") ?>
Dashboard | Dev Task
<?= $this->endSection() ?>

<?= $this->section("body") ?>

<div class="container" style="margin-top:20px;">
    <div class="row">
        <div class="panel panel-primary">
            <div class="panel-heading">
                <h1>Hello, <?= session()->get('professor_name') ?></h1>
                <h5>
                    <a href="<?= base_url('professor-profile') ?>"><i class="fa fa-user" aria-hidden="true"></i> Profile</a>
                    <a href="<?= base_url('professor-logout') ?>"><i class="fa fa-sign-out" aria-hidden="true"></i> Logout</a>
                </h5>
            </div>
        </div>
        <div class="panel panel-success">
            <div class="panel-heading">Dashboard</div>
                <div class="panel-body">
                     <a href="<?= base_url('professor-courses') ?>"><i class="fa fa-file-text" aria-hidden="true"></i> See available Courses</a>
                </div>
            </div>
        </div>
        <!-- <div class="panel panel-primary">
            <div class="panel-heading">Dashboard</div>
            <div class="panel-body">
                <h1>Hello, <?= session()->get('student_name') ?></h1>
                <h3><a href="<?= site_url('logout') ?>">Logout</a></h3>
                <a href="<?= site_url('courses') ?>">Courses</a>
            </div>
        </div> -->
    </div>
</div>

<?= $this->endSection() ?>