<?= $this->extend("Professor/layouts/app") ?>

<?= $this->section("pageTitle") ?>
Courses | Dev Task
<?= $this->endSection() ?>

<?= $this->section("body") ?>

<div class="container" style="margin-top:20px;">
    <div class="row">
        <div class="panel panel-primary">
            <div class="panel-heading">
                <h1>Courses</h1>
                <h5>
                    <a href="<?= base_url('professor-dashboard') ?>"><i class="fa fa-home" aria-hidden="true"></i> Home</a>
                    <a href="<?= base_url('professor-logout') ?>"><i class="fa fa-sign-out" aria-hidden="true"></i> Logout</a>
                </h5>
            </div>
        </div>
        <div class="panel panel-success">
            
                <div class="panel-body">
                <table id="courseTable">
            <tr>
              <th>Number</th>
              <th>Course</th>
              <th>Action</th>
            </tr>
            <?php
               if(count($allCourses) > 0):
                $i = 0;
                foreach($allCourses as $courses):
                  $i++;
                ?>
                <tr>
                  <td><?= $i; ?></td>
                  <td><?= $courses['course_name']; ?></td>
                  <td>
                    <?php 
                    if($courses['status'] != '0'):
                      echo '<a class="btn btn-primary" href="'.base_url().'/professor-enrolments/'.$courses['id'].'">View Enrolments</a>';
                    
                    else:
                      echo '<span class="label label-danger">Deactivated</span>';
                    endif
                    ?>
                  </td>
                  
                </tr>
                <?php
                endforeach
              ?>
              <?php
              else:
            ?>
            <tr>
              <td colspan="3">Sorry, No Courses to list!</td>
            </tr>
            <?php
            endif
              ?>
          </table>
                </div>
            </div>
        </div>
        
    </div>
</div>

<?= $this->endSection() ?>

