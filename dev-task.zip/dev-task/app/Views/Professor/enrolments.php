<?= $this->extend("Professor/layouts/app") ?>

<?= $this->section("pageTitle") ?>
Enrolments | Dev Task
<?= $this->endSection() ?>

<?= $this->section("body") ?>

<div class="container" style="margin-top:20px;">
    <div class="row">
        <div class="panel panel-primary">
            <div class="panel-heading">
                <h1>Enrolments for <?= $courseDetails['course_name']; ?></h1>
                <h5>
                    <a href="<?= base_url('professor-dashboard') ?>"><i class="fa fa-home" aria-hidden="true"></i> Home</a> |
                    <a href="<?= base_url('professor-courses') ?>"><i class="fa fa-file-text-o" aria-hidden="true"></i> Courses</a> |
                    <a href="<?= base_url('professor-logout') ?>"><i class="fa fa-sign-out" aria-hidden="true"></i> Logout</a>
                </h5>
            </div>
        </div>
        <div class="panel panel-success">
            
          <div class="panel-body">
          <table id="courseTable">
            <tr>
            <th>Number</th>
              <th>Student</th>
              <th>Student Comment</th>
              <th>Applied On</th>
              <th>Requested Exam Date</th>
              <th>Action</th>
            </tr>
            <?php
               if(count($allEnrolments) > 0):
                $i = 0;
                foreach($allEnrolments as $enrolments):
                  $i++;
                ?>
                <tr>
                  <td><?= $i; ?></td>
                  <td><?= $enrolments->student_name; ?></td>
                  <td>
                  <button type="button" class="btn btn-primary" data-toggle="modal" data-target="#viewComment<?= $enrolments->id; ?>">Read Comment</button>
                      <!-- Student Comment Modal -->
                      <div class="modal fade" id="viewComment<?= $enrolments->id; ?>" role="dialog">
                        <div class="modal-dialog modal-md">
                          <div class="modal-content">
                            <div class="modal-header">
                              <button type="button" class="close" data-dismiss="modal">&times;</button>
                              <h4 class="modal-title">Student Comment</h4>
                            </div>
                            <div class="modal-body">
                            <?= $enrolments->student_comment; ?>
                            </div>
                            <div class="modal-footer">
                              <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
                            </div>
                          </div>
                        </div>
                      </div>
                  </td>
                  <td>
                  <?php 
                    $requestTime = date('F jS, Y h:i:s a', strtotime($enrolments->request_time));
                  ?>
                  <?= $requestTime; ?>
                  
                  </td>
                  <td>
                    <?= date('F jS, Y h:i:s a', strtotime($enrolments->exam_date)); ?>
                  </td>
                  <td><span class="actionRow<?= $enrolments->id; ?>">
                    <?php
                     if($enrolments->approval_status == '0'):
                        
                      echo '<button class="btn btn-warning" onclick="takeaction('.$enrolments->id.');" >Approve/Decline</button>';
                    
                    elseif($enrolments->approval_status == '1'):
                      $approved_time = date('F jS, Y h:i:s a', strtotime($enrolments->approved_time));
                      echo '<span class="label label-success">Request Approved</span><br /> Professor :';
                      if($enrolments->profId == session()->get('Pid')):
                          echo "You";
                      
                      else:
                        echo $enrolments->professor_name;
                      endif
                      ?>
                     <br />Date - <?= $approved_time; ?>
                     <?php
                    
                      else:
                      $approved_time = date('F jS, Y h:i:s a', strtotime($enrolments->approved_time));
                      echo '<span class="label label-danger">Request Declined</span> <br />Professor :';
                      if($enrolments->profId == session()->get('Pid')):
                        echo "You";
                      
                      else:
                        echo $enrolments->professor_name;
                      endif
                      ?>
                      <br /> Date: <?= $approved_time; ?>
                      <?php
                    endif

                    ?></span>
                  </td>
                  
                </tr>
                <?php
                endforeach
              ?>
              <?php
              else:
            ?>
            <tr>
              <td colspan="6">Sorry, No Enrolments for this Course!</td>
            </tr>
            <?php
            endif
              ?>
          </table>



          <!-- Exam approve/decline Modal -->
          <div class="modal fade" id="examAction" role="dialog">
            <div class="modal-dialog modal-md">
              <div class="modal-content">
                <div class="modal-header">
                  <button type="button" class="close" data-dismiss="modal">&times;</button>
                  <h4 class="modal-title">Approve/Decline Exam Request</h4>
                </div>
                <div class="modal-body">
                  
                </div>
                <div class="modal-footer">
                  
                  <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
                  <button type="button" class="btn btn-primary submitBtn" style="display:none;" onclick="submitRequest();">SUBMIT</button>
                </div>
              </div>
            </div>
          </div>
                </div>
            </div>
        </div>
        <input type="hidden" class="txt_csrfname" name="<?= csrf_token() ?>" value="<?= csrf_hash() ?>">


        
    </div>
</div>

<?= $this->endSection() ?>

