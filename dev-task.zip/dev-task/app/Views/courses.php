<?= $this->extend("layouts/app") ?>

<?= $this->section("pageTitle") ?>
Courses | Dev Task
<?= $this->endSection() ?>

<?= $this->section("body") ?>

<div class="container" style="margin-top:20px;">
    <div class="row">
        <div class="panel panel-primary">
            <div class="panel-heading">
                <h1>Hello, <?= session()->get('student_name') ?></h1>
                <h5>
                <a href="<?= base_url('dashboard') ?>"><i class="fa fa-home" aria-hidden="true"></i> Home</a> | 
                    <a href="<?= base_url('logout') ?>"><i class="fa fa-sign-out" aria-hidden="true"></i> Logout</a>
                </h5>
            </div>
        </div>
        <div class="panel panel-success">
            <div class="panel-heading">Courses</div>
            <div class="panel-body">
                <table id="courseTable">
                    <tr>
                    <th>Number</th>
                    <th>Course</th>
                    <th>Exam Date Applied</th>
                    <th>Action</th>
                    </tr>
                    <?php
                    if(count($allCourses) > 0):
                        $i = 0;
                        foreach($allCourses as $courses):
                        $i++;
                        ?>
                        <tr>
                        <td><?= $i; ?></td>
                        <td><span class="courseName<?= $courses->id; ?>"><?= $courses->course_name; ?></span></td>
                        <td><span class="applyBox<?= $courses->id; ?>">
                            <?php 
                            if($courses->exam_date != ''):
                            ?>
                            
                            <?= date('F jS, Y h:i:s a', strtotime($courses->exam_date)); ?>
                           
                            <?php
                            else:
                            ?>
                            <?= '-'; ?>
                            <?php
                            endif
                            ?>
                             </span>
                        </td>
                        <td>
                            <?php
                            if($courses->request_time == ''):
                                echo '<span class="requestBox'.$courses->id.'"><button class="btn btn-primary" onclick="sendrequest('.$courses->id.');">Request</button>';
                            
                            else:
                                if($courses->approval_status == '0'):
                                    $requestTime = date('F jS, Y h:i:s a', strtotime($courses->request_time));
                                    echo '<span class="label label-warning">Request Pending (Applied on '.$requestTime.')</span>';
                                
                                elseif($courses->approval_status == '1'):
                                    $approved_time = date('F jS, Y h:i:s a', strtotime($courses->approved_time));
                                    echo '<span class="label label-success">Request Approved</span><br>Professor : '.$courses->professor_name.'<br>Time: '.$approved_time;
                                
                                else:
                                    $approved_time = date('F jS, Y h:i:s a', strtotime($courses->approved_time));
                                    echo '<span class="label label-danger">Request Declined </span><br>Professor : '.$courses->professor_name.'<br />Time :'.$approved_time;
                                endif;
                            endif;
                            
                            ?>
                        </td>
                        </tr>
                        <?php endforeach ?>
                    <?php
                        else:
                    ?>
                    <tr>
                    <td colspan="4">Sorry, No Courses to list!</td>
                    </tr>
                    <?php
                   endif
                    ?>
                </table>
            </div>
        </div>
    </div>
</div>

 <!-- Modal for registering exam -->
 <div class="modal fade" id="examReqModal">
    <div class="modal-dialog">
      <div class="modal-content">
      
        <!-- Modal Header -->
        <div class="modal-header">
          <h4 class="modal-title">Modal Heading</h4>
          <button type="button" class="close" data-dismiss="modal">&times;</button>
        </div>
        
        <!-- Modal body -->
        <div class="modal-body">
            <form method="post" action="javascript:void(0)">
                <input type="hidden" class="selectedCourseId" />
                <!--  csrf_field();  -->
               
                <input type="hidden" class="txt_csrfname" name="<?= csrf_token() ?>" value="<?= csrf_hash() ?>">
                <div class="screen1">
                <p>Please select a date and time and click on 'NEXT'</p>
                <div class="examdateValidation"></div>
                
                    <?php 
                    //$today = date("Y-m-d").'T'.date("h:i"); 
                    //date('Y-m-d', strtotime('+1 day', strtotime($date)))
                    $tomorrow = date('Y-m-d', strtotime('+1 day', strtotime(date("Y-m-d")))).'T'.date("h:i");
                    ?>
                <input type="datetime-local" id="examdaytime"  min="<?php echo $tomorrow; ?>"  required/>
                
                </div>
                <div class="screen2" style="display:none;">
                <span class="textToDisplay"></span>
                <br />
                <div>Enter your Comment:<span class="commentValidation">*</span></div>
                <textarea rows="4" cols="70" class="studentComment"></textarea>
                </div>
                <div class="screen3" style="display:none;">
                </div>
            </form>
        </div>
        
        <!-- Modal footer -->
        <div class="modal-footer">
            <button type="button" class="btn btn-primary nextBtn" onclick="showScreen2();">NEXT</button>
            <button type="button" class="btn btn-default closeBtn" style="display:none;" data-dismiss="modal">Close</button>
            <button type="button" class="btn btn-warning backBtn" style="display:none;" onclick="showScreen1();">BACK</button>
            <button type="button" class="btn btn-primary submitBtn" style="display:none;" onclick="submitRequest();">SUBMIT</button>
        </div>
        
      </div>
    </div>
  </div>

<?= $this->endSection() ?>